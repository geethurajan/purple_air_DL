"""
STAGE 3: Apply the log-linear calibration (from Stage 2) to every sensor's
readings during the pre-fire BASELINE window, interpolate to census tracts,
and average over time to get each tract's baseline (non-fire) PM2.5 -- PM_NF
in the paper's notation.

Run: python stage3_baseline_pm25.py
(Reads checkpoints from Stages 1 & 2.)

Writes to CHECKPOINTS_DIR:
    tract_baseline_pm25.csv   [tract_id, baseline_pm25]
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd

from pipeline_config import ckpt, BASELINE_START, BASELINE_END
from config import ALL_FEATURES
from data_utils import add_lagged_meteorology
from calibration_models import load_log_linear_params, predict_log_linear_from_params
from mortality_utils import interpolate_to_tracts, compute_tract_baseline_pm25


def main():
    print("Loading checkpoints...")
    all_sensors = pd.read_csv(ckpt("all_sensors_filtered.csv"), parse_dates=["timestamp"],
                               dtype={"sensor_id": str})
    tract_centroids = pd.read_csv(ckpt("tract_centroids.csv"))
    params = load_log_linear_params(ckpt("log_linear_params.csv"))

    print(f"Restricting to baseline window {BASELINE_START} to {BASELINE_END}...")
    baseline_sensors = all_sensors[
        (all_sensors["date"] >= BASELINE_START) & (all_sensors["date"] <= BASELINE_END)
    ].copy()
    print(f"  -> {len(baseline_sensors)} sensor-hours in the baseline window "
          f"across {baseline_sensors['sensor_id'].nunique()} sensors.")

    print("Applying calibration and lagged features...")
    baseline_lagged = add_lagged_meteorology(baseline_sensors, sensor_id_col="sensor_id")
    baseline_lagged["adjusted_pm25"] = predict_log_linear_from_params(
        params, baseline_lagged, features=ALL_FEATURES
    )

    print("Interpolating to census tracts (thin plate spline, per day)...")
    baseline_pm25_by_tract_day = interpolate_to_tracts(
        baseline_lagged, tract_centroids, value_col="adjusted_pm25", day_col="date"
    )

    tract_baseline_pm25 = compute_tract_baseline_pm25(baseline_pm25_by_tract_day)
    tract_baseline_pm25.to_csv(ckpt("tract_baseline_pm25.csv"), index=False)

    print(f"\nSTAGE 3 COMPLETE. Baseline PM2.5 computed for {len(tract_baseline_pm25)} tracts.")
    print(tract_baseline_pm25.describe())


if __name__ == "__main__":
    main()
