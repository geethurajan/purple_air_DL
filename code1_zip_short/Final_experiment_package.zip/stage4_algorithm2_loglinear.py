"""
STAGE 4: Run Algorithm 2 -- excess mortality via log-linear calibration,
with bootstrap variance -- over the wildfire EVENT window, using the
checkpoints from Stages 1-3.

Run: python stage4_algorithm2_loglinear.py

Writes to CHECKPOINTS_DIR:
    algo2_point_estimate.csv        [tract_id, M, U, B, T, CI_lower, CI_upper]
    algo2_bootstrap_replicates.csv  one row per (tract_id, bootstrap_iter)
    algo2_uniform_epa_only.csv      [tract_id, cumulative_M] -- EPA-only comparison
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd

from pipeline_config import (
    ckpt, EVENT_START, EVENT_END, N_BOOTSTRAP,
    GAMMA_POINT_, GAMMA_LO_, GAMMA_HI_, GBD_RATE_PER_100K_PER_YEAR,
)
from calibration_models import load_log_linear_params
from mortality_utils import compute_gbd_baseline_daily_mortality
from algorithm2_loglinear import run_algorithm2


def main():
    print("Loading checkpoints...")
    all_sensors = pd.read_csv(ckpt("all_sensors_filtered.csv"), parse_dates=["timestamp"],
                               dtype={"sensor_id": str})
    synchronized_calibration_data = pd.read_csv(ckpt("synchronized_calibration_data.csv"),
                                                 parse_dates=["timestamp"])
    tract_centroids = pd.read_csv(ckpt("tract_centroids.csv"))
    population = pd.read_csv(ckpt("population.csv"))
    tract_baseline_pm25 = pd.read_csv(ckpt("tract_baseline_pm25.csv"))
    epa_df = pd.read_csv(ckpt("epa_data.csv"), parse_dates=["timestamp"])
    params = load_log_linear_params(ckpt("log_linear_params.csv"))

    print(f"Restricting to event window {EVENT_START} to {EVENT_END}...")
    event_sensors = all_sensors[
        (all_sensors["date"] >= EVENT_START) & (all_sensors["date"] <= EVENT_END)
    ].copy()
    print(f"  -> {len(event_sensors)} sensor-hours across {event_sensors['sensor_id'].nunique()} sensors.")

    baseline_daily_mortality = compute_gbd_baseline_daily_mortality(
        population, yearly_rate_per_100k=GBD_RATE_PER_100K_PER_YEAR
    )

    epa_daily_df = (
        epa_df.assign(date=epa_df["timestamp"].dt.date.astype(str))
        .groupby("date", as_index=False)["epa_pm25"].mean()
    )
    epa_daily_df = epa_daily_df[(epa_daily_df["date"] >= EVENT_START) & (epa_daily_df["date"] <= EVENT_END)]

    print(f"\nRunning Algorithm 2 ({N_BOOTSTRAP} bootstrap replicates; this may take a while)...")
    algo2_results = run_algorithm2(
        full_data_log_linear_fit=params,
        synchronized_calibration_data=synchronized_calibration_data,
        all_sensor_readings_df=event_sensors,
        tract_centroids=tract_centroids,
        baseline_pm25=tract_baseline_pm25,
        gamma_point=GAMMA_POINT_, gamma_lo=GAMMA_LO_, gamma_hi=GAMMA_HI_,
        baseline_daily_mortality=baseline_daily_mortality,
        population=population,
        epa_daily_df=epa_daily_df,
        m=N_BOOTSTRAP,
    )

    algo2_results["point_estimate"].to_csv(ckpt("algo2_point_estimate.csv"), index=False)
    algo2_results["bootstrap_replicates"].to_csv(ckpt("algo2_bootstrap_replicates.csv"), index=False)
    algo2_results["uniform_epa_only"].to_csv(ckpt("algo2_uniform_epa_only.csv"), index=False)

    total_M = algo2_results["point_estimate"]["M"].sum()
    total_lo = algo2_results["point_estimate"]["CI_lower"].sum()
    total_hi = algo2_results["point_estimate"]["CI_upper"].sum()
    total_uniform = algo2_results["uniform_epa_only"]["cumulative_M"].sum()

    print(f"\nSTAGE 4 COMPLETE.")
    print(f"City-wide total excess mortality (log-linear, spatially resolved): "
          f"{total_M:.1f} [{total_lo:.1f}, {total_hi:.1f}]")
    print(f"City-wide total excess mortality (EPA-only, spatially uniform): {total_uniform:.1f}")


if __name__ == "__main__":
    main()
