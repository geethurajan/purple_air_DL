"""
STAGE 5: Run Algorithm 3 -- excess mortality via MLP calibration, with
retraining variance across an ensemble of independently-trained MLPs --
over the wildfire EVENT window.

This is the most expensive stage (retrains a full neural network N_MLP_RETRAIN
times). Progress prints after each retrain so you can monitor a long run.

Run: python stage5_algorithm3_mlp.py

Writes to CHECKPOINTS_DIR:
    algo3_ensemble_point_estimate.csv  [tract_id, M_mean, U_mean, B, T, CI_lower, CI_upper]
    algo3_per_run_replicates.csv       one row per (tract_id, run)
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd

from pipeline_config import (
    ckpt, EVENT_START, EVENT_END, N_MLP_RETRAIN,
    GAMMA_POINT_, GAMMA_LO_, GAMMA_HI_, GBD_RATE_PER_100K_PER_YEAR,
)
from mortality_utils import compute_gbd_baseline_daily_mortality
from algorithm3_mlp import run_algorithm3


def main():
    print("Loading checkpoints...")
    all_sensors = pd.read_csv(ckpt("all_sensors_filtered.csv"), parse_dates=["timestamp"],
                               dtype={"sensor_id": str})
    synchronized_calibration_data = pd.read_csv(ckpt("synchronized_calibration_data.csv"),
                                                 parse_dates=["timestamp"])
    tract_centroids = pd.read_csv(ckpt("tract_centroids.csv"))
    population = pd.read_csv(ckpt("population.csv"))
    tract_baseline_pm25 = pd.read_csv(ckpt("tract_baseline_pm25.csv"))

    print(f"Restricting to event window {EVENT_START} to {EVENT_END}...")
    event_sensors = all_sensors[
        (all_sensors["date"] >= EVENT_START) & (all_sensors["date"] <= EVENT_END)
    ].copy()
    print(f"  -> {len(event_sensors)} sensor-hours across {event_sensors['sensor_id'].nunique()} sensors.")

    baseline_daily_mortality = compute_gbd_baseline_daily_mortality(
        population, yearly_rate_per_100k=GBD_RATE_PER_100K_PER_YEAR
    )

    print(f"\nRunning Algorithm 3 ({N_MLP_RETRAIN} MLP retrains; this is the "
          f"slowest stage -- each retrain is a full neural network training run)...")
    algo3_results = run_algorithm3(
        full_training_data=synchronized_calibration_data,
        all_sensor_readings_df=event_sensors,
        tract_centroids=tract_centroids,
        baseline_pm25=tract_baseline_pm25,
        gamma_point=GAMMA_POINT_, gamma_lo=GAMMA_LO_, gamma_hi=GAMMA_HI_,
        baseline_daily_mortality=baseline_daily_mortality,
        population=population,
        m=N_MLP_RETRAIN,
    )

    algo3_results["ensemble_point_estimate"].to_csv(ckpt("algo3_ensemble_point_estimate.csv"), index=False)
    algo3_results["per_run_replicates"].to_csv(ckpt("algo3_per_run_replicates.csv"), index=False)

    total_M = algo3_results["ensemble_point_estimate"]["M_mean"].sum()
    total_lo = algo3_results["ensemble_point_estimate"]["CI_lower"].sum()
    total_hi = algo3_results["ensemble_point_estimate"]["CI_upper"].sum()

    print(f"\nSTAGE 5 COMPLETE.")
    print(f"City-wide total excess mortality (MLP ensemble): {total_M:.1f} [{total_lo:.1f}, {total_hi:.1f}]")


if __name__ == "__main__":
    main()
