# Wildfire PM2.5 Excess Mortality — Algorithms 1-4

Python implementation of the four algorithms from the paper, split across
files by responsibility so each piece can be read, tested, and modified
independently.

## File layout

| File | Purpose |
|---|---|
| `config.py` | Shared constants (replication counts, feature names, MLP architecture, z-value, spatial smoothing λ, LA projection reference point, γ and Bd defaults from the source paper). |
| `data_utils.py` | Timestamp synchronization, lagged meteorological features, leakage-resistant time-block splitting. Used by all three algorithms. |
| `calibration_models.py` | The log-linear regression and the MLP: fit / predict / R² helpers. |
| `thin_plate_spline.py` | **Faithful reimplementation of the paper's Eq. 6** — a penalized (smoothing, not exact-interpolation) thin plate spline with a fixed λ, solved via the classical radial-basis-function linear system. Operates in planar (km) coordinates, not raw lat/lon degrees. |
| `algorithm1_model_comparison.py` | **Algorithm 1** — fits the full-data log-linear model (carried forward to Algorithm 2) and runs the 50-iteration paired R² comparison vs. the MLP. |
| `mortality_utils.py` | Shared math for Algorithms 2 & 3: spatial interpolation (via `thin_plate_spline.py`), RR/AF/M computation (supports both a single city-wide baseline PM2.5 and a per-tract baseline matching the paper), variance combining (`T = U + B`), CI reporting, GBD-based Bd, and the spatially-uniform EPA-only comparison. |
| `algorithm2_loglinear.py` | **Algorithm 2** — point estimate from the full-data log-linear fit, plus 50-replicate bootstrap variance. |
| `algorithm3_mlp.py` | **Algorithm 3** — ensemble point estimate across 50 MLP retrains, plus retraining variance. |
| `algorithm4_visualization.py` | **Algorithm 4** — stub, matching the source paper marking this as "pending." Includes the one well-defined building block (per-tract difference vs. the uniform estimate). |
| `real_data_loaders.py` | Loaders for the real Los Angeles data: EPA AQS CSV, census tract centroids, city boundary, and the PurpleAir sensor network (including `filter_sensors_by_min_hours()` and `resample_to_hourly()`) — see "Real-data pipeline (Los Angeles)" below. |
| `run_pipeline.py` | End-to-end example wiring everything together with **synthetic** data. Run this first to confirm your environment works. |
| `run_real_data_pipeline.py` | One-shot end-to-end script wired to the **real** LA data files. Fine for small runs; for the full ~260-sensor network, prefer the **staged pipeline** below instead. |
| `pipeline_config.py` | Centralized settings (paths, event/baseline dates, replicate counts) for the staged pipeline — edit this ONE file instead of five. |
| `stage1_load_and_filter_sensors.py` … `stage5_algorithm3_mlp.py` | **Staged pipeline**, run one at a time — see below. |

## Installation

```bash
pip install -r requirements.txt
```

## Quick start (synthetic data)

```bash
python run_pipeline.py
```

## Staged pipeline (recommended for the full ~260-sensor network)

Each stage reads its inputs from checkpoint CSVs written by the previous stage (in `checkpoints/`) and writes its own outputs there too. This means you can run one stage at a time — in separate sessions, without keeping everything in memory or re-running expensive earlier steps — and inspect any intermediate result as a plain CSV before moving on.

1. Edit `pipeline_config.py` once: file paths, `MIN_SENSOR_HOURS` (default 120), `BASELINE_START`/`BASELINE_END`, `EVENT_START`/`EVENT_END`, and replicate counts (lower these for a fast first pass, raise to 50 for a final run).
2. Run in order:

```bash
python stage1_load_and_filter_sensors.py   # loads + resamples + filters sensors (>=120 hrs kept)
python stage2_algorithm1_calibration.py    # Algorithm 1: calibration + model comparison
python stage3_baseline_pm25.py             # per-tract pre-fire baseline PM2.5
python stage4_algorithm2_loglinear.py      # Algorithm 2: log-linear mortality + bootstrap
python stage5_algorithm3_mlp.py            # Algorithm 3: MLP ensemble mortality (slowest stage)
```

Each stage prints progress and a short summary; `checkpoints/sensor_hour_counts.csv` (from Stage 1) shows exactly which sensors were kept/dropped and why, and `checkpoints/*.csv` after Stages 4-5 hold the final tract-level results.

## Real-data pipeline (Los Angeles) — data sources

`real_data_loaders.py` is wired to:
- `LA_Site_1103.csv` — EPA AQS-format PM2.5 monitor, hourly, using its `Date Local`/`Time Local` columns directly (already local time, no timezone conversion needed).
- `la_city_tracts_final.csv` — census tract centroids + population. Its `x_km`/`y_km` columns are a simple equirectangular projection centered almost exactly on the EPA monitor (verified by regression: implied center 34.06659°N, -118.22688°W, ~111.19 km/° latitude, ~92.03 km/° longitude) — `real_data_loaders.project_to_km()` reproduces this exact projection so sensor coordinates land in the same system.
- `City_Boundary.geojson` — LA city boundary polygon (optional; for filtering sensors/tracts, or later mapping).
- `sensor_{code}_history.csv` — one file per PurpleAir sensor (~260 of them).

**Before running against your real ~260 sensor files**, three things need verifying, since no actual `sensor_*_history.csv` was available when this was written (only the EPA file, tract file, and boundary were):

1. **Column names / timestamp format.** `real_data_loaders.py` auto-detects columns from common PurpleAir export schemas (`_PM25_CANDIDATES`, `_TEMP_CANDIDATES`, etc.). Run `check_one_sensor_file("your/sensors/dir")` from `run_real_data_pipeline.py` on one real file first — if detection fails or looks wrong, either rename columns to match the candidate lists, or pass an explicit `column_map` to `load_purpleair_sensor_file()`.
2. **Sensor lat/lon.** PurpleAir per-sensor history exports typically do NOT include that sensor's lat/lon (it's static metadata). If yours don't either, set `SENSOR_METADATA_PATH` to a CSV of `[sensor_id, lat, lon]` (exportable from PurpleAir's sensor list/map), with `sensor_id` matching the `{code}` in each filename.
3. **Wildfire event dates.** Set `BASELINE_START`/`BASELINE_END` (a pre-fire period) and `EVENT_START`/`EVENT_END` in `run_real_data_pipeline.py` to your actual dates.

```bash
python run_real_data_pipeline.py
```

## Thin plate spline fidelity (important fix)

The source paper fits its spatial interpolation with R's `fields::Tps`, using a **fixed smoothing penalty λ = 10⁻³** for both the pre-fire and during-fire periods (Eq. 6) — this is a genuine *smoothing* spline that does not pass exactly through every sensor reading. An earlier version of this code used `scipy.interpolate.RBFInterpolator`'s default behavior, which is an **exact interpolator** — a real mismatch. `thin_plate_spline.py` now solves the same penalized variational problem directly (the classical `[K + λI, P; Pᵀ, 0]` linear system with `φ(r) = r²log(r)`), matching Eq. 6 exactly, with λ configurable in `config.py` (`SPATIAL_SMOOTHING_LAMBDA`, default `1e-3`). Fit/predict happen in planar km coordinates (see `project_to_km()`), since lat/lon degrees aren't an isotropic distance metric and would distort the spline.



## Plugging in real data for OTHER cities

For a city other than LA, `run_real_data_pipeline.py`'s loaders are LA-specific
(the projection reference point, etc.) but the pattern generalizes. Produce
these DataFrame shapes (see `real_data_loaders.py` for the LA versions):

- **`purpleair_df`**: `[timestamp, pa_pm25, pa_temp, pa_humidity, pa_pressure]` — the single PurpleAir sensor co-located with the EPA monitor, used for calibration.
- **`epa_df`**: `[timestamp, epa_pm25]` — matching EPA reference monitor readings.
- **`all_sensor_readings_df`**: `[sensor_id, timestamp, x_km, y_km, pa_pm25, pa_temp, pa_humidity, pa_pressure, date]` — every PurpleAir sensor in the network, for the wildfire event window. **Needs `x_km`/`y_km`** (planar projected coordinates), not raw lat/lon — see `real_data_loaders.project_to_km()`.
- **`tract_centroids`**: `[tract_id, x_km, y_km]`, in the SAME projection as the sensors.
- **`population`**: `[tract_id, population]`.
- **`baseline_daily_mortality`**: `[tract_id, Bd]` — baseline daily mortality rate per tract (`mortality_utils.compute_gbd_baseline_daily_mortality()` handles the GBD-rate-based version used in the paper).
- **`epa_daily_df`**: `[date, epa_pm25]` — for the spatially-uniform comparison estimate.
- **`gamma_point`, `gamma_lo`, `gamma_hi`, `baseline_pm25`**: from your exposure-response literature (`config.py` has the paper's Atkinson et al. 2014 defaults) and a pre-fire baseline period (`mortality_utils.compute_tract_baseline_pm25()`).

## Notes on faithfulness to the algorithm spec

- Algorithm 1's time-block split is **contiguous by day**, not row-wise random, specifically to avoid autocorrelation leakage inflating the MLP's R² — see `contiguous_time_block_split()`.
- Algorithm 2's point estimate uses **one fixed full-data OLS fit**; its 50 bootstrap replicates resample the *calibration data*, not the sensor network.
- Algorithm 3 has **no single deterministic fit** (per the paper's own note) — the point estimate is the **mean across 50 retrained MLPs**, and "B" here is retraining variance, not resampling variance. This is a deliberate asymmetry with Algorithm 2, not a bug.
- Both Algorithm 2 and 3 combine variance as a **simple sum `T = U + B`**, explicitly not Rubin's rules (the (1 + 1/m) correction doesn't apply here since `B` isn't multiple-imputation variance).
- Algorithm 4 is left as a stub because the source document marks it "pending — not yet specified."

## Performance note

Algorithm 3 retrains a full MLP `m` times (default 50), and Algorithm 2's
bootstrap refits are comparatively cheap OLS fits. For large sensor networks
or long event windows, Algorithm 3 will dominate runtime — consider reducing
`N_MLP_RETRAIN` in `config.py` during development/testing, as done in
`run_pipeline.py`'s demo call (`m=3`).
