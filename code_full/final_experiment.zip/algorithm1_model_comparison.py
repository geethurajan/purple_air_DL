"""
Algorithm 1: Sensor Calibration Model Comparison (Log-Linear vs. MLP)

Require: Closest PurpleAir sensor readings to the EPA reference monitor
         (PM2.5, temperature, humidity, pressure, timestamps), chronologically
         sorted; synchronized EPA PM2.5 readings.
Ensure:  Full-data log-linear calibration coefficients (point estimate,
         carried forward to Algorithm 2); paired R^2 distributions for
         log-linear vs. MLP on matched, time-blocked train/test splits.
"""

import numpy as np
import pandas as pd

from config import N_TIME_BLOCK_SPLITS, ALL_FEATURES
from data_utils import synchronize_calibration_data, add_lagged_meteorology, contiguous_time_block_split
from calibration_models import (
    fit_log_linear, evaluate_log_linear_r2,
    fit_mlp, evaluate_mlp_r2,
)


def run_algorithm1(purpleair_df: pd.DataFrame, epa_df: pd.DataFrame,
                    n_splits: int = N_TIME_BLOCK_SPLITS, seed: int = 42):
    """
    Full Algorithm 1 pipeline.

    Returns
    -------
    dict with:
        'full_data_log_linear_fit' : fitted statsmodels result (point estimate,
                                      carried forward to Algorithm 2, Step 2)
        'r2_results' : DataFrame with columns ['iteration', 'log_linear_r2', 'mlp_r2']
    """
    rng = np.random.default_rng(seed)

    # Steps 1-2: synchronize and add lagged features
    sync_df = synchronize_calibration_data(purpleair_df, epa_df)
    sync_df = add_lagged_meteorology(sync_df)

    # Step 3: fit log-linear model on the FULL synchronized dataset.
    # This is the point-estimate coefficient set carried forward to Algorithm 2.
    full_data_fit = fit_log_linear(sync_df, features=ALL_FEATURES)

    # Steps 4-9: paired time-block comparison, n_splits times
    records = []
    for i in range(1, n_splits + 1):
        train_df, test_df = contiguous_time_block_split(sync_df, rng=rng)

        if len(train_df) < 20 or len(test_df) < 5:
            # not enough data in this draw; skip and note it
            records.append({"iteration": i, "log_linear_r2": np.nan, "mlp_r2": np.nan})
            continue

        # log-linear: refit on this split's training block only
        ll_fit = fit_log_linear(train_df, features=ALL_FEATURES)
        ll_r2 = evaluate_log_linear_r2(ll_fit, test_df, features=ALL_FEATURES)

        # MLP: same training block, same held-out test block, same 7 predictors
        mlp_model = fit_mlp(train_df, features=ALL_FEATURES)
        mlp_r2 = evaluate_mlp_r2(mlp_model, test_df, features=ALL_FEATURES)

        records.append({"iteration": i, "log_linear_r2": ll_r2, "mlp_r2": mlp_r2})

    r2_results = pd.DataFrame(records)

    return {
        "full_data_log_linear_fit": full_data_fit,
        "full_data_log_linear_params": full_data_fit.params,
        "r2_results": r2_results,
        "synchronized_calibration_data": sync_df,  # needed for Algorithm 2's bootstrap
    }


def summarize_r2(r2_results: pd.DataFrame):
    """Step 10: aggregate the paired R^2 values for a quick comparison summary."""
    summary = r2_results[["log_linear_r2", "mlp_r2"]].agg(["mean", "std", "median"])
    win_rate_mlp = (r2_results["mlp_r2"] > r2_results["log_linear_r2"]).mean()
    summary.loc["mlp_win_rate"] = [np.nan, win_rate_mlp]
    return summary


if __name__ == "__main__":
    # Example / smoke-test usage with synthetic data.
    rng = np.random.default_rng(0)
    n = 24 * 60  # 60 days of hourly data
    timestamps = pd.date_range("2023-08-01", periods=n, freq="h")

    epa_pm25 = np.clip(20 + 15 * np.sin(np.linspace(0, 10, n)) + rng.normal(0, 3, n), 0.1, None)
    pa_pm25 = epa_pm25 * 1.3 + rng.normal(0, 2, n)
    temp = 25 + 5 * np.sin(np.linspace(0, 20, n)) + rng.normal(0, 1, n)
    humidity = 50 + 10 * np.cos(np.linspace(0, 15, n)) + rng.normal(0, 2, n)
    pressure = 1013 + rng.normal(0, 2, n)

    purpleair_df = pd.DataFrame({
        "timestamp": timestamps, "pa_pm25": np.clip(pa_pm25, 0, None),
        "pa_temp": temp, "pa_humidity": humidity, "pa_pressure": pressure,
    })
    epa_df = pd.DataFrame({"timestamp": timestamps, "epa_pm25": epa_pm25})

    results = run_algorithm1(purpleair_df, epa_df, n_splits=5)  # small n for a quick smoke test
    print(results["full_data_log_linear_fit"].summary())
    print(summarize_r2(results["r2_results"]))
