"""
Algorithm 2: Excess Mortality Estimation via Log-Linear Calibration
             (Bootstrap Variance, Explicit Point Estimate)

Require: Full-data log-linear coefficients from Algorithm 1; synchronized
         calibration data (for bootstrap resampling); raw PurpleAir readings
         at all sensors; census tract centroids and populations; gamma
         (point estimate + 95% CI); Bd; number of bootstrap replicates m=50.
Ensure:  Point-estimate tract-level excess mortality (from the full-data
         calibration), with a combined 95% CI reflecting both
         calibration-model (bootstrap) uncertainty and gamma's
         exposure-response uncertainty; comparison against a
         spatially-uniform EPA-only estimate.

NOTE: works with a plain coefficients Series (not a live statsmodels result
object) throughout, so a pipeline stage can load coefficients from a
checkpoint CSV (see calibration_models.save/load_log_linear_params) without
needing to keep the fitted model object around across stages. A full
statsmodels result object also works transparently (its `.params` is used).
"""

import numpy as np
import pandas as pd

from config import N_BOOTSTRAP, ALL_FEATURES
from data_utils import add_lagged_meteorology
from calibration_models import fit_log_linear, predict_log_linear_from_params
from mortality_utils import (
    interpolate_to_tracts, compute_mortality_with_ci_bounds,
    combine_variance_simple_sum, report_ci, compute_uniform_epa_only_mortality,
)


def _as_params(fit_or_params):
    """Accepts either a statsmodels result (uses .params) or a plain Series."""
    return fit_or_params.params if hasattr(fit_or_params, "params") else fit_or_params


def _apply_calibration_to_all_sensors(params, all_sensor_readings_df, sensor_id_col="sensor_id"):
    """Steps 1-2: lag features per-sensor, then apply the log-linear coefficients."""
    lagged = add_lagged_meteorology(all_sensor_readings_df, sensor_id_col=sensor_id_col)
    lagged["adjusted_pm25"] = predict_log_linear_from_params(params, lagged, features=ALL_FEATURES)
    return lagged


def _point_estimate_run(params, all_sensor_readings_df, tract_centroids,
                         baseline_pm25, gamma_point, gamma_lo, gamma_hi,
                         baseline_daily_mortality, population, sensor_id_col="sensor_id",
                         day_col="date"):
    """
    One full pass of Steps 1-4: calibrate all sensors -> interpolate to tracts
    -> compute cumulative M at gamma point/lo/hi. Reused for both the "official"
    point estimate and every bootstrap replicate (Step 7).
    """
    adjusted = _apply_calibration_to_all_sensors(params, all_sensor_readings_df, sensor_id_col)

    pm25_by_tract_day = interpolate_to_tracts(
        adjusted, tract_centroids, value_col="adjusted_pm25", day_col=day_col
    )

    result = compute_mortality_with_ci_bounds(
        pm25_by_tract_day, baseline_pm25, gamma_point, gamma_lo, gamma_hi,
        baseline_daily_mortality, population, pm25_col="pm25_interpolated", day_col=day_col,
    )
    return result


def run_algorithm2(full_data_log_linear_fit, synchronized_calibration_data: pd.DataFrame,
                    all_sensor_readings_df: pd.DataFrame, tract_centroids: pd.DataFrame,
                    baseline_pm25, gamma_point: float, gamma_lo: float, gamma_hi: float,
                    baseline_daily_mortality: pd.DataFrame, population: pd.DataFrame,
                    epa_daily_df: pd.DataFrame, m: int = N_BOOTSTRAP, seed: int = 42,
                    sensor_id_col: str = "sensor_id", day_col: str = "date",
                    bootstrap_progress_every: int = 10):
    """
    Full Algorithm 2 pipeline.

    Parameters
    ----------
    full_data_log_linear_fit : EITHER a fitted statsmodels result from
        Algorithm 1, Step 3, OR a plain coefficients Series (e.g. loaded via
        calibration_models.load_log_linear_params() from a checkpoint CSV).
    synchronized_calibration_data : the same synchronized EPA/PurpleAir DataFrame
        used in Algorithm 1, used here purely as the bootstrap resampling pool.
    all_sensor_readings_df : raw PurpleAir readings at ALL sensors (not just the
        one co-located with the EPA monitor), columns include
        [sensor_id_col, timestamp, x_km, y_km, pa_pm25, pa_temp, pa_humidity, pa_pressure].
    tract_centroids : DataFrame ['tract_id', 'x_km', 'y_km'].
    baseline_pm25 : counterfactual/background PM2.5 level for delta calculation
        -- either a single float, or a DataFrame ['tract_id', 'baseline_pm25'].
    gamma_point, gamma_lo, gamma_hi : exposure-response coefficient and its 95% CI bounds.
    baseline_daily_mortality : DataFrame ['tract_id', 'Bd'].
    population : DataFrame ['tract_id', 'population'].
    epa_daily_df : DataFrame [day_col, 'epa_pm25'] for the uniform comparison estimate.
    m : number of bootstrap replicates.
    bootstrap_progress_every : print a progress line every N bootstrap iterations
        (bootstrapping over a full sensor network can take a while; this gives
        visibility into progress for a long-running standalone stage script).

    Returns
    -------
    dict with:
        'point_estimate' : DataFrame ['tract_id', 'M', 'CI_lower', 'CI_upper']
        'bootstrap_replicates' : DataFrame, one row per (tract_id, bootstrap iteration)
        'uniform_epa_only' : DataFrame ['tract_id', 'cumulative_M']
    """
    rng = np.random.default_rng(seed)
    params = _as_params(full_data_log_linear_fit)

    # ---- Point estimate (once), Steps 1-4 -------------------------------
    point_result = _point_estimate_run(
        params, all_sensor_readings_df, tract_centroids,
        baseline_pm25, gamma_point, gamma_lo, gamma_hi,
        baseline_daily_mortality, population, sensor_id_col, day_col,
    )
    # point_result has columns: tract_id, M, M_lo, M_hi, U

    # ---- Bootstrap variance, Steps 5-8 -----------------------------------
    bootstrap_records = []
    n_rows = len(synchronized_calibration_data)

    for i in range(1, m + 1):
        # Step 6: resample calibration data with replacement, refit log-linear model
        boot_idx = rng.integers(0, n_rows, size=n_rows)
        boot_sample = synchronized_calibration_data.iloc[boot_idx].reset_index(drop=True)
        boot_params = fit_log_linear(boot_sample, features=ALL_FEATURES).params

        # Step 7: repeat the point-estimate steps using the resampled coefficients
        boot_result = _point_estimate_run(
            boot_params, all_sensor_readings_df, tract_centroids,
            baseline_pm25, gamma_point, gamma_lo, gamma_hi,
            baseline_daily_mortality, population, sensor_id_col, day_col,
        )
        boot_result["bootstrap_iter"] = i
        bootstrap_records.append(boot_result[["tract_id", "M", "bootstrap_iter"]])

        if bootstrap_progress_every and i % bootstrap_progress_every == 0:
            print(f"  [Algorithm 2] bootstrap replicate {i}/{m} done")

    bootstrap_replicates = pd.concat(bootstrap_records, ignore_index=True)

    # ---- Step 9: combine variance ---------------------------------------
    B = (
        bootstrap_replicates.groupby("tract_id")["M"]
        .var(ddof=1)
        .rename("B")
        .reset_index()
    )

    combined = point_result.merge(B, on="tract_id", how="left")
    combined["T"] = combine_variance_simple_sum(combined["U"], combined["B"])

    # ---- Step 10: report point estimate + 95% CI -------------------------
    lower, upper = report_ci(combined["M"], combined["T"])
    combined["CI_lower"] = lower
    combined["CI_upper"] = upper

    point_estimate_out = combined[["tract_id", "M", "U", "B", "T", "CI_lower", "CI_upper"]]

    # ---- Steps 11-12: spatially-uniform EPA-only comparison --------------
    uniform_epa_only = compute_uniform_epa_only_mortality(
        epa_daily_df, baseline_pm25, gamma_point, baseline_daily_mortality,
        population, pm25_col="epa_pm25", day_col=day_col,
    )

    return {
        "point_estimate": point_estimate_out,
        "bootstrap_replicates": bootstrap_replicates,
        "uniform_epa_only": uniform_epa_only,
    }
