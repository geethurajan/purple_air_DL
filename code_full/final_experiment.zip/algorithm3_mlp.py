"""
Algorithm 3: Excess Mortality Estimation via MLP Calibration
             (Retraining Variance, Ensemble Point Estimate)

Require: MLP architecture from Algorithm 1; raw PurpleAir readings at all
         sensors; census tract centroids and populations; gamma (point
         estimate + 95% CI); Bd; number of retraining replicates m=50.
Ensure:  Ensemble-average tract-level excess mortality with a combined 95%
         CI reflecting both MLP retraining variability and gamma's
         exposure-response uncertainty.

Note on asymmetry with Algorithm 2: unlike OLS, the MLP has no single
deterministic "full-data" solution -- each training run converges
differently due to random initialization and dropout. The point estimate
here is therefore the ENSEMBLE MEAN across the m retrained models, not a
single privileged run. This is a genuine, acknowledged difference from
Algorithm 2's point estimate (a fixed full-data OLS fit), not an oversight.
"""

import numpy as np
import pandas as pd

from config import N_MLP_RETRAIN, ALL_FEATURES
from data_utils import add_lagged_meteorology
from calibration_models import fit_mlp, predict_mlp
from mortality_utils import (
    interpolate_to_tracts, compute_mortality_with_ci_bounds, combine_variance_simple_sum, report_ci,
)


def _apply_mlp_to_all_sensors(model, all_sensor_readings_df, sensor_id_col="sensor_id"):
    """Steps 3-4: lag features per-sensor, then apply the trained MLP."""
    lagged = add_lagged_meteorology(all_sensor_readings_df, sensor_id_col=sensor_id_col)
    lagged["adjusted_pm25"] = predict_mlp(model, lagged, features=ALL_FEATURES)
    return lagged


def run_algorithm3(full_training_data: pd.DataFrame, all_sensor_readings_df: pd.DataFrame,
                    tract_centroids: pd.DataFrame, baseline_pm25: float,
                    gamma_point: float, gamma_lo: float, gamma_hi: float,
                    baseline_daily_mortality: pd.DataFrame, population: pd.DataFrame,
                    m: int = N_MLP_RETRAIN, sensor_id_col: str = "sensor_id",
                    day_col: str = "date", verbose_training: int = 0,
                    progress_every: int = 1):
    """
    Full Algorithm 3 pipeline.

    Parameters
    ----------
    full_training_data : synchronized calibration DataFrame (same as fed into
        Algorithm 1) used to train the MLP from scratch each of the m times.
    all_sensor_readings_df : raw PurpleAir readings at ALL sensors.
    tract_centroids : DataFrame ['tract_id', 'lat', 'lon'].
    baseline_pm25, gamma_point, gamma_lo, gamma_hi : as in Algorithm 2.
    baseline_daily_mortality : DataFrame ['tract_id', 'Bd'].
    population : DataFrame ['tract_id', 'population'].
    m : number of MLP retraining replicates.

    Returns
    -------
    dict with:
        'ensemble_point_estimate' : DataFrame ['tract_id', 'M_mean', 'U_mean',
                                                'B', 'T', 'CI_lower', 'CI_upper']
        'per_run_replicates' : DataFrame, one row per (tract_id, run) with M_i and U_i
    """
    run_records = []

    for i in range(1, m + 1):
        # Step 2: fresh random init/dropout, train on the full dataset, early stopping
        model = fit_mlp(full_training_data, features=ALL_FEATURES, verbose=verbose_training)

        # Steps 3-4: apply to every sensor (with lagged features) -> adjusted PM2.5
        adjusted = _apply_mlp_to_all_sensors(model, all_sensor_readings_df, sensor_id_col)

        # Step 5: thin plate spline interpolation to tract centroids, per day
        pm25_by_tract_day = interpolate_to_tracts(
            adjusted, tract_centroids, value_col="adjusted_pm25", day_col=day_col
        )

        # Step 6: cumulative M at gamma point/lo/hi for this run, plus within-run U_i (Step 7)
        run_result = compute_mortality_with_ci_bounds(
            pm25_by_tract_day, baseline_pm25, gamma_point, gamma_lo, gamma_hi,
            baseline_daily_mortality, population, pm25_col="pm25_interpolated", day_col=day_col,
        )
        run_result["run"] = i
        run_records.append(run_result[["tract_id", "M", "U", "run"]])

        if progress_every and i % progress_every == 0:
            print(f"  [Algorithm 3] MLP retrain {i}/{m} done")

    per_run_replicates = pd.concat(run_records, ignore_index=True)

    # ---- Step 9: ensemble aggregation across the m runs -------------------
    agg = per_run_replicates.groupby("tract_id").agg(
        M_mean=("M", "mean"),
        U_mean=("U", "mean"),
        B=("M", lambda s: s.var(ddof=1)),
    ).reset_index()

    agg["T"] = combine_variance_simple_sum(agg["U_mean"], agg["B"])

    # ---- Step 10: report ensemble point estimate + 95% CI ------------------
    lower, upper = report_ci(agg["M_mean"], agg["T"])
    agg["CI_lower"] = lower
    agg["CI_upper"] = upper

    ensemble_point_estimate = agg[["tract_id", "M_mean", "U_mean", "B", "T", "CI_lower", "CI_upper"]]

    return {
        "ensemble_point_estimate": ensemble_point_estimate,
        "per_run_replicates": per_run_replicates,
    }
