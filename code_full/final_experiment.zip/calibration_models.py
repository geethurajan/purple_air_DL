"""
Calibration model definitions: the log-linear regression and the MLP,
both predicting EPA PM2.5 from PurpleAir + meteorological features.
"""

import numpy as np
import pandas as pd
import statsmodels.api as sm
from sklearn.metrics import r2_score

from config import (
    ALL_FEATURES, MLP_HIDDEN_LAYERS, MLP_DROPOUT_RATE,
    MLP_EPOCHS, MLP_BATCH_SIZE, MLP_EARLY_STOPPING_PATIENCE,
)


# ---------------------------------------------------------------------------
# Log-linear model
# ---------------------------------------------------------------------------

def fit_log_linear(df, features=None):
    """
    Algorithm 1, Step 3 / used again inside Algorithm 2 (full-data fit and
    each bootstrap refit).

    Fits: log(EPA_t) = b0 + bPM*log(PA.PM_t) + bT*PA.T_t + bRH*PA.RH_t + bP*PA.P_t
                        + bT,-1*PA.T_{t-1} + bRH,-1*PA.RH_{t-1} + bP,-1*PA.P_{t-1} + eps_t

    Parameters
    ----------
    df : DataFrame containing the 7 predictor columns and 'epa_pm25'.
    features : optional override of predictor column names.

    Returns
    -------
    statsmodels RegressionResultsWrapper (the fitted OLS model). Use
    `.params` for coefficients and `predict_log_linear()` below for
    predictions on new data.
    """
    features = features or ALL_FEATURES

    y = np.log(df["epa_pm25"].to_numpy(dtype=float).clip(min=1e-6))

    X = df[features].copy()
    # PM2.5 enters in log-space; meteorological terms enter linearly, per Algorithm 1
    X["pa_pm25"] = np.log(X["pa_pm25"].clip(lower=1e-6))
    X = sm.add_constant(X, has_constant="add")

    model = sm.OLS(y, X, missing="drop")
    result = model.fit()
    return result


def predict_log_linear(fitted_result, df, features=None):
    """
    Apply a fitted log-linear model to new data (e.g. all PurpleAir sensors
    in Algorithm 2). Returns predictions in the ORIGINAL (non-log) PM2.5 scale.
    """
    features = features or ALL_FEATURES

    X = df[features].copy()
    X["pa_pm25"] = np.log(X["pa_pm25"].clip(lower=1e-6))
    X = sm.add_constant(X, has_constant="add")

    # ensure column order matches training
    X = X[fitted_result.params.index]

    log_pred = fitted_result.predict(X)
    return np.exp(log_pred)


def evaluate_log_linear_r2(fitted_result, test_df, features=None):
    """R^2 of a fitted log-linear model on a held-out block (Algorithm 1, Step 6)."""
    y_true = test_df["epa_pm25"].to_numpy(dtype=float)
    y_pred = predict_log_linear(fitted_result, test_df, features=features)
    return r2_score(y_true, y_pred)


def save_log_linear_params(fitted_result, path: str):
    """
    Saves just the fitted coefficients (a small pandas Series) to CSV, so a
    later pipeline stage can apply the calibration WITHOUT needing to keep
    the full statsmodels result object (or refit anything) across stages.
    """
    fitted_result.params.to_csv(path, header=["coefficient"])


def load_log_linear_params(path: str) -> pd.Series:
    """Loads coefficients saved by save_log_linear_params() back into a pandas Series."""
    return pd.read_csv(path, index_col=0)["coefficient"]


def predict_log_linear_from_params(params: pd.Series, df, features=None):
    """
    Same as predict_log_linear(), but takes a plain coefficients Series
    (e.g. loaded from a checkpoint CSV via load_log_linear_params()) instead
    of a live statsmodels result object. Returns predictions in the
    ORIGINAL (non-log) PM2.5 scale.
    """
    features = features or ALL_FEATURES

    X = df[features].copy()
    X["pa_pm25"] = np.log(X["pa_pm25"].clip(lower=1e-6))
    X = sm.add_constant(X, has_constant="add")
    X = X[params.index]

    log_pred = X.to_numpy() @ params.to_numpy()
    return np.exp(log_pred)


# ---------------------------------------------------------------------------
# MLP model
# ---------------------------------------------------------------------------

def build_mlp(input_dim: int):
    """
    Algorithm 1, Step 7 / Algorithm 3, Step 2.

    Dense(128, ReLU) -> BatchNorm -> Dropout(0.3) -> Dense(64, ReLU)
      -> Dense(32, ReLU) -> Dense(1)
    """
    from tensorflow import keras
    from tensorflow.keras import layers

    model = keras.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(MLP_HIDDEN_LAYERS[0], activation="relu"),
        layers.BatchNormalization(),
        layers.Dropout(MLP_DROPOUT_RATE),
        layers.Dense(MLP_HIDDEN_LAYERS[1], activation="relu"),
        layers.Dense(MLP_HIDDEN_LAYERS[2], activation="relu"),
        layers.Dense(1),
    ])
    model.compile(optimizer="adam", loss="mse")
    return model


def fit_mlp(train_df, val_df=None, features=None, epochs=MLP_EPOCHS,
            batch_size=MLP_BATCH_SIZE, verbose=0):
    """
    Train the MLP on the given training data, predicting EPA PM2.5 directly
    (not in log-space, unlike the log-linear model) from the same 7 predictors.

    If val_df is not provided, a random 15% slice of train_df is held out
    internally purely for early-stopping (this is separate from, and does not
    replace, the Algorithm-1 time-block test split).
    """
    from tensorflow import keras

    features = features or ALL_FEATURES

    X_train = train_df[features].to_numpy(dtype=float)
    y_train = train_df["epa_pm25"].to_numpy(dtype=float)

    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=MLP_EARLY_STOPPING_PATIENCE,
            restore_best_weights=True,
        )
    ]

    model = build_mlp(input_dim=X_train.shape[1])

    if val_df is not None:
        X_val = val_df[features].to_numpy(dtype=float)
        y_val = val_df["epa_pm25"].to_numpy(dtype=float)
        model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs, batch_size=batch_size,
            callbacks=callbacks, verbose=verbose,
        )
    else:
        model.fit(
            X_train, y_train,
            validation_split=0.15,
            epochs=epochs, batch_size=batch_size,
            callbacks=callbacks, verbose=verbose,
        )

    return model


def predict_mlp(model, df, features=None):
    features = features or ALL_FEATURES
    X = df[features].to_numpy(dtype=float)
    return model.predict(X, verbose=0).flatten()


def evaluate_mlp_r2(model, test_df, features=None):
    """R^2 of a trained MLP on a held-out block (Algorithm 1, Step 7)."""
    y_true = test_df["epa_pm25"].to_numpy(dtype=float)
    y_pred = predict_mlp(model, test_df, features=features)
    return r2_score(y_true, y_pred)
