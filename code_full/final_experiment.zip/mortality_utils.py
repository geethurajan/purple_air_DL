"""
Shared mortality-estimation utilities used by both Algorithm 2 (log-linear)
and Algorithm 3 (MLP):
  - thin plate spline spatial interpolation from sensors to census tracts
  - daily RR / AF / M computation from an exposure-response gamma
  - combining independent variance components into a 95% CI
  - the "spatially-uniform, EPA-only" comparison estimate

NOTE ON Bd: the algorithms reference "Bd", the daily baseline mortality
count/rate for the population of interest. This must be supplied by the
caller (e.g. from vital-statistics data for the study region). The
standard attributable-fraction formula used here is:

    RR  = exp(gamma * delta_PM2.5)
    AF  = (RR - 1) / RR
    M   = AF * Bd * Population          (excess deaths attributable to PM2.5)
"""

import numpy as np
import pandas as pd

from config import Z_95, SPATIAL_SMOOTHING_LAMBDA
from thin_plate_spline import ThinPlateSpline


# ---------------------------------------------------------------------------
# Spatial interpolation
# ---------------------------------------------------------------------------

def interpolate_to_tracts(sensor_df: pd.DataFrame, tract_centroids: pd.DataFrame,
                           value_col: str = "adjusted_pm25", day_col: str = "date",
                           lambda_: float = SPATIAL_SMOOTHING_LAMBDA):
    """
    Algorithm 2, Step 3 / Algorithm 3, Step 5.

    Fit the paper's penalized thin plate spline (Eq. 6, fixed lambda) over
    sensor-adjusted PM2.5 values and interpolate to every census tract
    centroid, separately for each day in the event window.

    IMPORTANT: this operates in a PLANAR coordinate system, not raw lat/lon.
    `sensor_df` must contain 'x_km'/'y_km' columns, and `tract_centroids`
    must contain 'x_km'/'y_km' columns, both computed from the SAME
    projection reference point (see real_data_loaders.project_to_km).

    Parameters
    ----------
    sensor_df : DataFrame with columns [day_col, 'x_km', 'y_km', value_col] —
        one row per sensor per day (already calibrated/adjusted PM2.5).
    tract_centroids : DataFrame with columns ['tract_id', 'x_km', 'y_km'].
    value_col : name of the PM2.5 column to interpolate.
    day_col : name of the date column to loop over.
    lambda_ : thin plate spline smoothing penalty (paper fixes this at 1e-3).

    Returns
    -------
    DataFrame with columns ['tract_id', day_col, 'pm25_interpolated'].
    """
    tract_coords = tract_centroids[["x_km", "y_km"]].to_numpy()

    records = []
    for day, day_df in sensor_df.groupby(day_col):
        day_df = day_df.dropna(subset=[value_col, "x_km", "y_km"])

        # Collapse to one value per sensor location for this day (e.g. mean of
        # hourly adjusted readings). The spline is spatial-only, so duplicate
        # coordinates (multiple hours at the same sensor) would otherwise make
        # the interpolation system singular.
        day_df = day_df.groupby(["x_km", "y_km"], as_index=False)[value_col].mean()

        if len(day_df) < 3:
            # not enough sensors to fit a spline this day; skip (caller may
            # choose to forward-fill or otherwise handle gaps)
            continue

        coords = day_df[["x_km", "y_km"]].to_numpy()
        values = day_df[value_col].to_numpy()

        tps = ThinPlateSpline(lambda_=lambda_).fit(coords, values)
        interpolated = tps.predict(tract_coords)

        for tract_id, val in zip(tract_centroids["tract_id"], interpolated):
            records.append({"tract_id": tract_id, day_col: day, "pm25_interpolated": val})

    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# RR / AF / M (relative risk, attributable fraction, excess mortality)
# ---------------------------------------------------------------------------

def compute_daily_mortality(pm25_by_tract_day: pd.DataFrame, baseline_pm25, gamma: float,
                             baseline_daily_mortality: pd.DataFrame, population: pd.DataFrame,
                             pm25_col: str = "pm25_interpolated", day_col: str = "date"):
    """
    Compute daily RR, AF, and M per tract at a single gamma value, then sum
    across all days in the event window to get cumulative M per tract.

    Used identically by:
      - Algorithm 2, Step 4 (point estimate) and each bootstrap replicate
      - Algorithm 3, Step 6, for each of the m retraining replicates

    Parameters
    ----------
    pm25_by_tract_day : DataFrame ['tract_id', day_col, pm25_col] — interpolated
        PM2.5 for every tract, every day of the event window.
    baseline_pm25 : the non-event (counterfactual/background) PM2.5 level used
        to compute delta_PM2.5 = pm25_by_tract_day - baseline_pm25. Either:
          - a single float applied city-wide, or
          - a DataFrame ['tract_id', 'baseline_pm25'] giving a tract-specific
            value (the paper computes this as the temporal average of daily
            mean concentrations recorded before the fire period, per tract).
    gamma : exposure-response coefficient (point estimate, or gamma_lo/gamma_hi
        when called for CI bounds).
    baseline_daily_mortality : DataFrame ['tract_id', 'Bd'] — baseline daily
        mortality rate or count per tract.
    population : DataFrame ['tract_id', 'population'].

    Returns
    -------
    DataFrame ['tract_id', 'cumulative_M'] — summed over all days in the window.
    """
    df = pm25_by_tract_day.copy()

    if isinstance(baseline_pm25, pd.DataFrame):
        df = df.merge(baseline_pm25[["tract_id", "baseline_pm25"]], on="tract_id", how="left")
        df["delta_pm25"] = df[pm25_col] - df["baseline_pm25"]
    else:
        df["delta_pm25"] = df[pm25_col] - baseline_pm25

    df["RR"] = np.exp(gamma * df["delta_pm25"])
    df["AF"] = (df["RR"] - 1) / df["RR"]

    df = df.merge(baseline_daily_mortality, on="tract_id", how="left")
    df = df.merge(population, on="tract_id", how="left")

    df["M_daily"] = df["AF"] * df["Bd"] * df["population"]

    cumulative = df.groupby("tract_id", as_index=False)["M_daily"].sum()
    cumulative = cumulative.rename(columns={"M_daily": "cumulative_M"})
    return cumulative


def compute_mortality_with_ci_bounds(pm25_by_tract_day, baseline_pm25, gamma_point,
                                      gamma_lo, gamma_hi, baseline_daily_mortality,
                                      population, pm25_col="pm25_interpolated", day_col="date"):
    """
    Convenience wrapper: computes cumulative M at gamma point estimate, gamma_lo,
    and gamma_hi in one call. Returns a single DataFrame with all three, plus
    the within-estimate variance U (Algorithm 2 Step 9 / Algorithm 3 Step 7).
    """
    m_point = compute_daily_mortality(pm25_by_tract_day, baseline_pm25, gamma_point,
                                       baseline_daily_mortality, population, pm25_col, day_col)
    m_lo = compute_daily_mortality(pm25_by_tract_day, baseline_pm25, gamma_lo,
                                    baseline_daily_mortality, population, pm25_col, day_col)
    m_hi = compute_daily_mortality(pm25_by_tract_day, baseline_pm25, gamma_hi,
                                    baseline_daily_mortality, population, pm25_col, day_col)

    out = m_point.rename(columns={"cumulative_M": "M"})
    out = out.merge(m_lo.rename(columns={"cumulative_M": "M_lo"}), on="tract_id")
    out = out.merge(m_hi.rename(columns={"cumulative_M": "M_hi"}), on="tract_id")

    out["U"] = ((out["M_hi"] - out["M_lo"]) / (2 * Z_95)) ** 2
    return out


# ---------------------------------------------------------------------------
# Baseline (PM_NF) and baseline mortality (Bd) helpers, matching the paper
# ---------------------------------------------------------------------------

def compute_tract_baseline_pm25(pm25_by_tract_day: pd.DataFrame, pm25_col: str = "pm25_interpolated"):
    """
    PM_NF, per the paper: "the temporal average of daily mean concentrations
    recorded before the fire period," computed PER CENSUS TRACT (since the
    interpolated field already varies spatially before the fire too).

    Parameters
    ----------
    pm25_by_tract_day : the output of interpolate_to_tracts() run over the
        PRE-FIRE (non-fire) period only.

    Returns
    -------
    DataFrame ['tract_id', 'baseline_pm25'] — pass this directly as the
    `baseline_pm25` argument to compute_daily_mortality() /
    compute_mortality_with_ci_bounds().
    """
    baseline = (
        pm25_by_tract_day.groupby("tract_id", as_index=False)[pm25_col]
        .mean()
        .rename(columns={pm25_col: "baseline_pm25"})
    )
    return baseline


def compute_gbd_baseline_daily_mortality(population: pd.DataFrame,
                                          yearly_rate_per_100k: float = 780.0) -> pd.DataFrame:
    """
    Converts a yearly baseline mortality rate (per 100,000 people) -- the
    paper uses 780/100,000/year from the Global Burden of Disease study 2017
    for US non-communicable disease mortality -- into a per-person, per-day
    baseline mortality rate (Bd) for each census tract.

    Note: Bd in Eq. 8 (M = Bd * P_tot * AF) is a PER-PERSON daily rate, since
    it gets multiplied by P_tot separately. Bd itself is the SAME scalar rate
    for every tract in the paper (population only enters at the M = Bd * P_tot
    * AF step, not folded into Bd).

    Parameters
    ----------
    population : DataFrame ['tract_id', 'population'] (only used to produce
        one row of Bd per tract_id present).
    yearly_rate_per_100k : yearly baseline mortality rate per 100,000 people.

    Returns
    -------
    DataFrame ['tract_id', 'Bd'] where Bd is a per-person, per-day rate
    (identical across tracts, as in the paper).
    """
    daily_rate_per_person = (yearly_rate_per_100k / 100_000) / 365.0
    return pd.DataFrame({
        "tract_id": population["tract_id"],
        "Bd": daily_rate_per_person,
    })


# ---------------------------------------------------------------------------
# Variance combining / CI reporting
# ---------------------------------------------------------------------------

def combine_variance_simple_sum(u: pd.Series, b: pd.Series) -> pd.Series:
    """
    T = U + B: a simple sum of two independent uncertainty sources.
    Deliberately NOT Rubin's rules -- the bootstrap/retraining variance here
    is not multiple-imputation variance, so the (1 + 1/m) correction does
    not apply.
    """
    return u + b


def report_ci(point_estimate: pd.Series, total_variance: pd.Series):
    """Returns (lower, upper) 95% CI bounds: point_estimate +/- 1.96 * sqrt(T)."""
    margin = Z_95 * np.sqrt(total_variance)
    return point_estimate - margin, point_estimate + margin


# ---------------------------------------------------------------------------
# Spatially-uniform, EPA-only comparison estimate
# ---------------------------------------------------------------------------

def compute_uniform_epa_only_mortality(epa_daily_df: pd.DataFrame, baseline_pm25: float,
                                        gamma: float, baseline_daily_mortality: pd.DataFrame,
                                        population: pd.DataFrame, pm25_col: str = "epa_pm25",
                                        day_col: str = "date"):
    """
    Algorithm 2, Step 11 / used identically for the MLP comparison in
    Algorithm 3's writeup.

    Applies the SAME EPA monitor reading to every tract (no spatial
    variation), summed the same way over the event window, for comparison
    against the spatially-resolved calibrated estimates.
    """
    tract_ids = population["tract_id"].unique()

    # broadcast EPA's single time series to every tract
    epa_expanded = (
        epa_daily_df[[day_col, pm25_col]]
        .assign(key=1)
        .merge(pd.DataFrame({"tract_id": tract_ids, "key": 1}), on="key")
        .drop(columns="key")
    )

    return compute_daily_mortality(
        epa_expanded, baseline_pm25, gamma, baseline_daily_mortality, population,
        pm25_col=pm25_col, day_col=day_col,
    )
