"""
Centralized settings for the staged LA pipeline (stage1_...py through
stage5_...py). Edit paths/dates here ONCE; every stage script imports from
this file.

WHY STAGES: each stage reads its inputs from checkpoint CSVs written by the
previous stage (in CHECKPOINTS_DIR) and writes its own outputs there too.
This means:
  - You can run one stage at a time, in separate sessions, without needing
    to keep everything in memory or re-run expensive earlier steps.
  - If something looks off in an intermediate result, you can inspect the
    checkpoint CSV directly before moving to the next stage.
  - Re-running stage N doesn't require re-running stages 1..N-1.

Run them in order:
    python stage1_load_and_filter_sensors.py
    python stage2_algorithm1_calibration.py
    python stage3_baseline_pm25.py
    python stage4_algorithm2_loglinear.py
    python stage5_algorithm3_mlp.py
"""

import os

from config import GAMMA_POINT, GAMMA_LO, GAMMA_HI, GBD_BASELINE_MORTALITY_PER_100K_PER_YEAR

# ------------------------------------------------------------------------
# --- File paths: edit these ------------------------------------------------
# ------------------------------------------------------------------------
EPA_PATH = "LA_Site_1103.csv"
TRACTS_PATH = "la_city_tracts_final.csv"
BOUNDARY_PATH = "City_Boundary.geojson"

PURPLEAIR_SENSORS_DIR = "purpleair_sensors"        # <-- your ~260 sensor_{code}_history.csv files
SENSOR_METADATA_PATH = "sensor_metadata.csv"       # <-- CSV of [sensor_id, lat, lon]; set to None if lat/lon are in the files themselves

CHECKPOINTS_DIR = "checkpoints"
os.makedirs(CHECKPOINTS_DIR, exist_ok=True)


def ckpt(filename: str) -> str:
    """Shorthand: checkpoints/<filename>"""
    return os.path.join(CHECKPOINTS_DIR, filename)


# ------------------------------------------------------------------------
# --- Sensor quality filter --------------------------------------------------
# ------------------------------------------------------------------------
MIN_SENSOR_HOURS = 120   # only sensors with at least this many hourly readings are kept

# ------------------------------------------------------------------------
# --- Wildfire event window and pre-fire baseline window --------------------
# --- EDIT to match your actual event; must fall within LA_Site_1103.csv's --
# --- date coverage. ----------------------------------------------------------
# ------------------------------------------------------------------------
BASELINE_START, BASELINE_END = "2025-07-01", "2025-07-31"
EVENT_START, EVENT_END = "2025-08-01", "2025-08-20"

# ------------------------------------------------------------------------
# --- Replicate counts (bootstrap / MLP retrains) ----------------------------
# --- Lower these for a fast first pass, raise to 50 (paper spec) for a -----
# --- final run. --------------------------------------------------------------
# ------------------------------------------------------------------------
N_TIME_BLOCK_SPLITS = 50   # Algorithm 1's R^2 comparison
N_BOOTSTRAP = 50           # Algorithm 2's bootstrap
N_MLP_RETRAIN = 50         # Algorithm 3's retraining ensemble

# ------------------------------------------------------------------------
# --- Exposure-response and baseline mortality (paper defaults) -------------
# ------------------------------------------------------------------------
GAMMA_POINT_ = GAMMA_POINT
GAMMA_LO_ = GAMMA_LO
GAMMA_HI_ = GAMMA_HI
GBD_RATE_PER_100K_PER_YEAR = GBD_BASELINE_MORTALITY_PER_100K_PER_YEAR
