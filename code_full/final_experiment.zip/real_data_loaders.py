"""
Real-data loaders for the Los Angeles application of Algorithms 1-3.

Handles:
  - LA_Site_1103.csv            (EPA AQS monitor -- PM2.5, hourly, local time)
  - la_city_tracts_final.csv    (census tract centroids, population, and
                                  pre-computed x_km/y_km projected coordinates)
  - City_Boundary.geojson       (LA city boundary polygon, for optional
                                  sensor/tract filtering)
  - sensor_{code}_history.csv   (~260 PurpleAir sensor history files)

CONFIRMED REAL SCHEMA (from sensor_82071_history.csv): columns are
`time_stamp, pm2.5_cf_1, humidity, temperature, pressure`. Timestamps are
ISO strings with the UTC offset already embedded (e.g.
"2025-01-01 00:00:00-08:00") -- NOT epoch seconds, and NOT UTC needing
conversion; `load_purpleair_sensor_file()` handles this correctly either
way since pd.to_datetime respects the embedded offset. Temperature is in
Fahrenheit (confirmed by range: 40-97 for a Jan-Feb LA file). There is NO
lat/lon column in the per-sensor file, confirming you need a separate
sensor metadata CSV (see `load_sensor_metadata()` below).

NOTE ON pm2.5_cf_1 vs pm2.5_atm: the source paper specifically pulled the
"PM2.5 ATM" field ("with no additional conversion"), but the real files use
the "CF=1" processing field instead (PurpleAir reports both from the same
raw counts, using different internal correction curves -- CF=1 is often
preferred for smoke/high-concentration events, ATM for typical ambient
conditions). Since only CF=1 is available in your files, that's what
`_PM25_CANDIDATES` below picks up automatically. This is a minor, flagged
deviation from the paper's exact field choice, not a bug -- if you also
have access to the ATM field for these sensors, prefer it for closer
fidelity to the source methodology.
"""

import glob
import os
import re

import numpy as np
import pandas as pd

from config import LA_PROJECTION_REF_LAT, LA_PROJECTION_REF_LON, LA_KM_PER_DEG_LAT, LA_KM_PER_DEG_LON


# ---------------------------------------------------------------------------
# Projection: lat/lon -> planar km, consistent with la_city_tracts_final.csv
# ---------------------------------------------------------------------------

def project_to_km(lat, lon, ref_lat: float = LA_PROJECTION_REF_LAT, ref_lon: float = LA_PROJECTION_REF_LON,
                   km_per_deg_lat: float = LA_KM_PER_DEG_LAT, km_per_deg_lon: float = LA_KM_PER_DEG_LON):
    """
    Simple equirectangular projection: x_km = km_per_deg_lon * (lon - ref_lon),
    y_km = km_per_deg_lat * (lat - ref_lat).

    The defaults reproduce EXACTLY the x_km/y_km columns already present in
    la_city_tracts_final.csv (verified by regression: correlation ~1.0,
    implied reference point ~34.06659 N, -118.22688 W -- i.e. the EPA
    monitor's own location). Use this same function for sensor and EPA
    coordinates so every distance in the thin plate spline is on one
    consistent scale.
    """
    lat = np.asarray(lat, dtype=float)
    lon = np.asarray(lon, dtype=float)
    x_km = km_per_deg_lon * (lon - ref_lon)
    y_km = km_per_deg_lat * (lat - ref_lat)
    return x_km, y_km


# ---------------------------------------------------------------------------
# EPA monitor data
# ---------------------------------------------------------------------------

def load_epa_data(path: str) -> pd.DataFrame:
    """
    Loads the EPA AQS-format CSV (e.g. LA_Site_1103.csv).

    Uses 'Date Local' + 'Time Local' (already local time, no timezone
    conversion needed) to build a timestamp column. If multiple POC
    (monitor channel) values are present, keeps only the first one found and
    warns, since Algorithm 1 expects a single reference time series.

    Returns
    -------
    DataFrame ['timestamp', 'epa_pm25', 'latitude', 'longitude'], sorted
    chronologically.
    """
    df = pd.read_csv(path)

    pm25_rows = df[df["Parameter Code"] == 88101].copy()
    if pm25_rows.empty:
        # fall back to the Parameter Name in case the code differs
        pm25_rows = df[df["Parameter Name"].str.contains("PM2.5", case=False, na=False)].copy()

    poc_values = pm25_rows["POC"].unique()
    if len(poc_values) > 1:
        print(f"[load_epa_data] Multiple POC values found {poc_values}; keeping POC={poc_values[0]} only.")
        pm25_rows = pm25_rows[pm25_rows["POC"] == poc_values[0]]

    pm25_rows["timestamp"] = pd.to_datetime(
        pm25_rows["Date Local"] + " " + pm25_rows["Time Local"], errors="coerce"
    )
    pm25_rows = pm25_rows.dropna(subset=["timestamp"])

    out = pm25_rows.rename(columns={
        "Sample Measurement": "epa_pm25",
        "Latitude": "latitude",
        "Longitude": "longitude",
    })[["timestamp", "epa_pm25", "latitude", "longitude"]]

    out = out.sort_values("timestamp").drop_duplicates(subset="timestamp").reset_index(drop=True)
    return out


def get_epa_site_location(epa_df: pd.DataFrame):
    """Returns (lat, lon) of the EPA monitor (constant across all rows)."""
    return float(epa_df["latitude"].iloc[0]), float(epa_df["longitude"].iloc[0])


# ---------------------------------------------------------------------------
# Census tracts
# ---------------------------------------------------------------------------

def load_tract_data(path: str):
    """
    Loads la_city_tracts_final.csv.

    Returns
    -------
    (tract_centroids, population) where:
        tract_centroids : DataFrame ['tract_id', 'lat', 'lon', 'x_km', 'y_km']
        population       : DataFrame ['tract_id', 'population']
    """
    df = pd.read_csv(path)
    df = df.rename(columns={
        "GEOID": "tract_id",
        "centroid_lat": "lat",
        "centroid_lon": "lon",
    })

    tract_centroids = df[["tract_id", "lat", "lon", "x_km", "y_km"]].copy()
    population = df[["tract_id", "population"]].copy()

    return tract_centroids, population


# ---------------------------------------------------------------------------
# City boundary (optional -- for filtering / later visualization)
# ---------------------------------------------------------------------------

def load_city_boundary(path: str):
    """
    Loads City_Boundary.geojson as a shapely Polygon/MultiPolygon.
    Use `point_in_boundary()` below to filter sensors/tracts to the city limits.
    """
    import json
    from shapely.geometry import shape

    with open(path) as f:
        gj = json.load(f)

    geoms = [shape(feat["geometry"]) for feat in gj["features"]]
    if len(geoms) == 1:
        return geoms[0]
    from shapely.ops import unary_union
    return unary_union(geoms)


def point_in_boundary(lat, lon, boundary) -> bool:
    """Check whether a (lat, lon) point falls within the loaded city boundary polygon."""
    from shapely.geometry import Point
    return boundary.contains(Point(lon, lat))  # geojson coordinates are (lon, lat)


def filter_to_boundary(df: pd.DataFrame, boundary, lat_col: str = "lat", lon_col: str = "lon") -> pd.DataFrame:
    """Keep only rows whose (lat_col, lon_col) fall inside the boundary polygon."""
    from shapely.geometry import Point
    mask = df.apply(lambda r: boundary.contains(Point(r[lon_col], r[lat_col])), axis=1)
    return df[mask].reset_index(drop=True)


# ---------------------------------------------------------------------------
# PurpleAir sensor network
# ---------------------------------------------------------------------------

_SENSOR_FILENAME_PATTERN = re.compile(r"sensor_(\w{4,6})_history\.csv$")

# Priority-ordered candidate column names for each field. First match wins.
# EDIT THESE if your actual files use different names.
_TIMESTAMP_CANDIDATES = ["time_stamp", "created_at", "timestamp", "Time", "DateTime", "date_time"]
_PM25_CANDIDATES = [
    "pm2.5_cf_1",  # confirmed field in the real sensor_*_history.csv files
    "pm2.5_atm", "pm2.5_atm_a", "PM2.5_ATM_ug/m3",
    "pm2.5", "PM2.5", "pm25_atm", "pm25",
]
_TEMP_CANDIDATES = ["temperature", "Temperature_F", "temp", "Temperature"]
_HUMIDITY_CANDIDATES = ["humidity", "Humidity_%", "RH", "Humidity"]
_PRESSURE_CANDIDATES = ["pressure", "Pressure_hpa", "pressure_hpa", "Pressure"]
_LAT_CANDIDATES = ["lat", "latitude", "Lat", "Latitude"]
_LON_CANDIDATES = ["lon", "longitude", "Lon", "Longitude"]


def _first_matching_column(columns, candidates):
    cols_lower = {c.lower(): c for c in columns}
    for cand in candidates:
        if cand in columns:
            return cand
        if cand.lower() in cols_lower:
            return cols_lower[cand.lower()]
    return None


def discover_purpleair_files(directory: str):
    """
    Scans `directory` for files matching sensor_{code}_history.csv and
    returns a list of (sensor_id, filepath) tuples.
    """
    found = []
    for path in sorted(glob.glob(os.path.join(directory, "sensor_*_history.csv"))):
        m = _SENSOR_FILENAME_PATTERN.search(os.path.basename(path))
        if m:
            found.append((m.group(1), path))
    return found


def load_purpleair_sensor_file(path: str, sensor_id: str, column_map: dict = None,
                                temperature_in_fahrenheit: bool = True,
                                timestamps_are_utc: bool = True,
                                local_timezone: str = "America/Los_Angeles"):
    """
    Loads a single sensor_{code}_history.csv into a standardized DataFrame.

    Parameters
    ----------
    column_map : optional dict overriding auto-detection, e.g.
        {"timestamp": "created_at", "pm25": "pm2.5_atm", "temp": "temperature",
         "humidity": "humidity", "pressure": "pressure"}
    temperature_in_fahrenheit : PurpleAir sensors commonly report temperature
        in Fahrenheit by default; set False if yours are already Celsius.
    timestamps_are_utc : PurpleAir's API commonly reports timestamps in UTC;
        set False if you downloaded with a "local time" option already applied.
    local_timezone : used to convert from UTC to local time to match the EPA
        data's "Date Local"/"Time Local" convention, if timestamps_are_utc.

    Returns
    -------
    DataFrame ['sensor_id', 'timestamp', 'pa_pm25', 'pa_temp', 'pa_humidity',
               'pa_pressure'] plus ['lat', 'lon'] if found in the file.

    Raises
    ------
    ValueError if the timestamp or PM2.5 column can't be identified -- these
    two are required; temperature/humidity/pressure are filled with NaN
    (and lagged-feature rows dropped later) if genuinely absent, since the
    calibration model needs all 7 predictors, but this at least lets you
    inspect what WAS found before deciding.
    """
    df = pd.read_csv(path)
    column_map = column_map or {}

    ts_col = column_map.get("timestamp") or _first_matching_column(df.columns, _TIMESTAMP_CANDIDATES)
    pm25_col = column_map.get("pm25") or _first_matching_column(df.columns, _PM25_CANDIDATES)

    if ts_col is None or pm25_col is None:
        raise ValueError(
            f"Could not auto-detect required columns in {path}.\n"
            f"Columns found: {list(df.columns)}\n"
            f"Timestamp column detected: {ts_col!r}; PM2.5 column detected: {pm25_col!r}\n"
            f"Pass an explicit column_map={{'timestamp': '...', 'pm25': '...'}} to override."
        )

    temp_col = column_map.get("temp") or _first_matching_column(df.columns, _TEMP_CANDIDATES)
    hum_col = column_map.get("humidity") or _first_matching_column(df.columns, _HUMIDITY_CANDIDATES)
    pres_col = column_map.get("pressure") or _first_matching_column(df.columns, _PRESSURE_CANDIDATES)
    lat_col = column_map.get("lat") or _first_matching_column(df.columns, _LAT_CANDIDATES)
    lon_col = column_map.get("lon") or _first_matching_column(df.columns, _LON_CANDIDATES)

    out = pd.DataFrame()
    # try epoch seconds first, then generic parsing. Works correctly whether
    # the source is UTC epoch, UTC ISO strings, or (as confirmed in the real
    # sensor_*_history.csv files) ISO strings with the UTC offset already
    # embedded, e.g. "2025-01-01 00:00:00-08:00" -- pandas respects any
    # embedded offset regardless of the utc= flag.
    raw_ts = df[ts_col]
    if pd.api.types.is_numeric_dtype(raw_ts):
        out["timestamp"] = pd.to_datetime(raw_ts, unit="s", utc=timestamps_are_utc, errors="coerce")
    else:
        out["timestamp"] = pd.to_datetime(raw_ts, utc=timestamps_are_utc, errors="coerce")

    # Normalize to naive local time regardless of how it parsed, since the
    # rest of the pipeline (EPA merge, lagged features) expects naive
    # timestamps throughout. If parsing produced a naive series (no offset
    # info anywhere and utc=False), there's nothing to convert.
    if pd.api.types.is_datetime64tz_dtype(out["timestamp"]):
        out["timestamp"] = out["timestamp"].dt.tz_convert(local_timezone).dt.tz_localize(None)

    # assign AFTER 'timestamp' establishes the row index/length, so this
    # broadcasts correctly across all rows instead of only the first
    out["sensor_id"] = sensor_id

    out["pa_pm25"] = pd.to_numeric(df[pm25_col], errors="coerce")
    out["pa_temp"] = pd.to_numeric(df[temp_col], errors="coerce") if temp_col else np.nan
    if temperature_in_fahrenheit and temp_col is not None:
        out["pa_temp"] = (out["pa_temp"] - 32) * 5.0 / 9.0
    out["pa_humidity"] = pd.to_numeric(df[hum_col], errors="coerce") if hum_col else np.nan
    out["pa_pressure"] = pd.to_numeric(df[pres_col], errors="coerce") if pres_col else np.nan

    if lat_col is not None and lon_col is not None:
        out["lat"] = pd.to_numeric(df[lat_col], errors="coerce")
        out["lon"] = pd.to_numeric(df[lon_col], errors="coerce")

    out = out.dropna(subset=["timestamp", "pa_pm25"]).sort_values("timestamp").reset_index(drop=True)
    return out


def load_sensor_metadata(path: str, sensor_id_col: str = "sensor_id",
                          lat_col: str = "lat", lon_col: str = "lon") -> pd.DataFrame:
    """
    Loads a separate sensor metadata CSV (sensor_id, lat, lon), needed only
    if lat/lon are NOT present in each sensor_*_history.csv itself.

    The sensor_id values must match the {code} extracted from
    sensor_{code}_history.csv filenames.
    """
    meta = pd.read_csv(path)
    meta = meta.rename(columns={sensor_id_col: "sensor_id", lat_col: "lat", lon_col: "lon"})
    meta["sensor_id"] = meta["sensor_id"].astype(str)
    return meta[["sensor_id", "lat", "lon"]]


def load_all_purpleair_sensors(directory: str, metadata_path: str = None,
                                column_map: dict = None, **kwargs) -> pd.DataFrame:
    """
    Discovers and loads every sensor_{code}_history.csv in `directory`,
    attaches lat/lon (from the files themselves if present, else from
    `metadata_path`), projects to x_km/y_km, and concatenates into one
    long-format DataFrame ready for add_lagged_meteorology() /
    interpolate_to_tracts().

    Returns
    -------
    DataFrame ['sensor_id', 'timestamp', 'date', 'lat', 'lon', 'x_km', 'y_km',
               'pa_pm25', 'pa_temp', 'pa_humidity', 'pa_pressure']
    """
    files = discover_purpleair_files(directory)
    if not files:
        raise FileNotFoundError(
            f"No files matching sensor_*_history.csv found in {directory}. "
            "Check the directory path, or that files follow the expected naming pattern."
        )

    metadata = load_sensor_metadata(metadata_path) if metadata_path else None

    frames = []
    errors = []
    for sensor_id, path in files:
        try:
            sensor_df = load_purpleair_sensor_file(path, sensor_id, column_map=column_map, **kwargs)
        except ValueError as e:
            errors.append(str(e))
            continue

        if "lat" not in sensor_df.columns or "lon" not in sensor_df.columns:
            if metadata is None:
                errors.append(
                    f"Sensor {sensor_id}: no lat/lon in file and no metadata_path provided."
                )
                continue
            meta_row = metadata[metadata["sensor_id"] == sensor_id]
            if meta_row.empty:
                errors.append(f"Sensor {sensor_id}: not found in metadata file {metadata_path}.")
                continue
            sensor_df["lat"] = meta_row["lat"].iloc[0]
            sensor_df["lon"] = meta_row["lon"].iloc[0]

        frames.append(sensor_df)

    if errors:
        print(f"[load_all_purpleair_sensors] {len(errors)} sensor(s) skipped:")
        for e in errors[:10]:
            print("  -", e)
        if len(errors) > 10:
            print(f"  ... and {len(errors) - 10} more.")

    if not frames:
        raise RuntimeError("No sensor files could be loaded successfully -- see errors above.")

    all_sensors = pd.concat(frames, ignore_index=True)
    all_sensors["date"] = all_sensors["timestamp"].dt.date.astype(str)
    all_sensors["x_km"], all_sensors["y_km"] = project_to_km(all_sensors["lat"], all_sensors["lon"])

    return all_sensors


def resample_to_hourly(sensor_df: pd.DataFrame, sensor_id_col: str = "sensor_id") -> pd.DataFrame:
    """
    PurpleAir sensors commonly report every ~2 minutes; the EPA monitor and
    Algorithms 1-3 operate on an hourly cadence. Resamples each sensor's
    readings to hourly means.

    Parameters
    ----------
    sensor_df : DataFrame with a 'timestamp' column and value columns
        ['pa_pm25', 'pa_temp', 'pa_humidity', 'pa_pressure'], optionally
        grouped by sensor_id_col (pass None if this is a single sensor's data).

    Returns
    -------
    DataFrame with the same columns, one row per hour (per sensor, if grouped).
    """
    value_cols = [c for c in ["pa_pm25", "pa_temp", "pa_humidity", "pa_pressure"] if c in sensor_df.columns]
    static_cols = [c for c in ["lat", "lon", "x_km", "y_km"] if c in sensor_df.columns]

    def _resample_group(g):
        g = g.set_index("timestamp").sort_index()
        hourly = g[value_cols].resample("h").mean()
        for c in static_cols:
            hourly[c] = g[c].iloc[0]
        return hourly.reset_index()

    if sensor_id_col and sensor_id_col in sensor_df.columns:
        out = sensor_df.groupby(sensor_id_col, group_keys=True).apply(_resample_group, include_groups=False)
        out = out.reset_index(level=0).reset_index(drop=True)
    else:
        out = _resample_group(sensor_df)

    out = out.dropna(subset=["pa_pm25"]).reset_index(drop=True)
    if "date" not in out.columns and "timestamp" in out.columns:
        out["date"] = out["timestamp"].dt.date.astype(str)
    return out


def find_closest_sensor(all_sensors_df: pd.DataFrame, ref_lat: float, ref_lon: float) -> str:
    """
    Finds the sensor_id whose (lat, lon) is closest to a reference point
    (e.g. the EPA monitor), for use as Algorithm 1's calibration sensor.
    """
    ref_x, ref_y = project_to_km(ref_lat, ref_lon)
    locations = all_sensors_df[["sensor_id", "x_km", "y_km"]].drop_duplicates(subset="sensor_id")
    dist = np.sqrt((locations["x_km"] - ref_x) ** 2 + (locations["y_km"] - ref_y) ** 2)
    return locations.loc[dist.idxmin(), "sensor_id"]


def filter_sensors_by_min_hours(all_sensors_df: pd.DataFrame, min_hours: int = 120):
    """
    Keeps only sensors with at least `min_hours` rows of (hourly) data.
    Run this AFTER resample_to_hourly() so each row is one hour.

    Returns
    -------
    (filtered_df, hour_counts) where:
        filtered_df  : all_sensors_df restricted to qualifying sensors
        hour_counts  : DataFrame ['sensor_id', 'n_hours', 'kept'] for every
                       sensor seen, so you can inspect what got dropped.
    """
    counts = all_sensors_df.groupby("sensor_id").size().rename("n_hours").reset_index()
    counts["kept"] = counts["n_hours"] >= min_hours

    keep_ids = counts.loc[counts["kept"], "sensor_id"]
    filtered = all_sensors_df[all_sensors_df["sensor_id"].isin(keep_ids)].reset_index(drop=True)

    print(f"[filter_sensors_by_min_hours] {counts['kept'].sum()} of {len(counts)} sensors "
          f"meet the {min_hours}-hour threshold.")

    return filtered, counts
