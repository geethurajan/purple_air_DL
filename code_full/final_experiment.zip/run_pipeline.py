"""
Example orchestration script: shows how Algorithms 1-3 connect together,
using synthetic data so it runs out-of-the-box. Replace the synthetic data
generation with your real PurpleAir/EPA/census data and this same wiring
should work.

Run with:  python run_pipeline.py
"""

import numpy as np
import pandas as pd

from algorithm1_model_comparison import run_algorithm1, summarize_r2
from algorithm2_loglinear import run_algorithm2
from algorithm3_mlp import run_algorithm3
from algorithm4_visualization import compute_difference_from_uniform


def make_synthetic_data(seed: int = 0):
    rng = np.random.default_rng(seed)

    # --- calibration data: one sensor co-located with the EPA monitor ------
    n_hours = 24 * 45  # 45 days
    timestamps = pd.date_range("2023-08-01", periods=n_hours, freq="h")

    epa_pm25 = np.clip(20 + 15 * np.sin(np.linspace(0, 8, n_hours)) + rng.normal(0, 3, n_hours), 0.1, None)
    pa_pm25 = epa_pm25 * 1.3 + rng.normal(0, 2, n_hours)
    temp = 25 + 5 * np.sin(np.linspace(0, 15, n_hours)) + rng.normal(0, 1, n_hours)
    humidity = 50 + 10 * np.cos(np.linspace(0, 12, n_hours)) + rng.normal(0, 2, n_hours)
    pressure = 1013 + rng.normal(0, 2, n_hours)

    purpleair_df = pd.DataFrame({
        "timestamp": timestamps, "pa_pm25": np.clip(pa_pm25, 0, None),
        "pa_temp": temp, "pa_humidity": humidity, "pa_pressure": pressure,
    })
    epa_df = pd.DataFrame({"timestamp": timestamps, "epa_pm25": epa_pm25})

    # --- all-sensor network data (event window only, e.g. 10 days) ---------
    event_days = pd.date_range("2023-09-01", periods=10, freq="D")
    n_sensors = 15
    sensor_ids = [f"sensor_{i}" for i in range(n_sensors)]
    sensor_lats = rng.uniform(33.5, 34.5, n_sensors)
    sensor_lons = rng.uniform(-118.5, -117.5, n_sensors)

    rows = []
    for sid, lat, lon in zip(sensor_ids, sensor_lats, sensor_lons):
        for day in event_days:
            for hour in range(24):
                ts = day + pd.Timedelta(hours=hour)
                rows.append({
                    "sensor_id": sid, "timestamp": ts, "lat": lat, "lon": lon,
                    "pa_pm25": np.clip(30 + rng.normal(0, 8), 0, None),
                    "pa_temp": 28 + rng.normal(0, 2),
                    "pa_humidity": 40 + rng.normal(0, 5),
                    "pa_pressure": 1012 + rng.normal(0, 1),
                })
    all_sensor_readings_df = pd.DataFrame(rows)
    all_sensor_readings_df["date"] = all_sensor_readings_df["timestamp"].dt.date.astype(str)

    # --- census tracts -------------------------------------------------------
    n_tracts = 8
    tract_centroids = pd.DataFrame({
        "tract_id": [f"tract_{i}" for i in range(n_tracts)],
        "lat": rng.uniform(33.5, 34.5, n_tracts),
        "lon": rng.uniform(-118.5, -117.5, n_tracts),
    })
    # planar km coordinates for the thin plate spline (fit/predict must happen
    # in an isotropic coordinate system, not raw lat/lon degrees)
    ref_lat, ref_lon = 34.0, -118.0
    tract_centroids["x_km"] = (tract_centroids["lon"] - ref_lon) * 92.0
    tract_centroids["y_km"] = (tract_centroids["lat"] - ref_lat) * 111.0
    all_sensor_readings_df["x_km"] = (all_sensor_readings_df["lon"] - ref_lon) * 92.0
    all_sensor_readings_df["y_km"] = (all_sensor_readings_df["lat"] - ref_lat) * 111.0
    population = pd.DataFrame({
        "tract_id": tract_centroids["tract_id"],
        "population": rng.integers(2000, 20000, n_tracts),
    })
    baseline_daily_mortality = pd.DataFrame({
        "tract_id": tract_centroids["tract_id"],
        "Bd": rng.uniform(0.00015, 0.00025, n_tracts),  # baseline daily mortality rate
    })

    # --- EPA-only comparison series over the event window ---------------------
    epa_daily_df = pd.DataFrame({
        "date": [d.strftime("%Y-%m-%d") for d in event_days],
        "epa_pm25": np.clip(35 + rng.normal(0, 6, len(event_days)), 0, None),
    })

    return {
        "purpleair_df": purpleair_df,
        "epa_df": epa_df,
        "all_sensor_readings_df": all_sensor_readings_df,
        "tract_centroids": tract_centroids,
        "population": population,
        "baseline_daily_mortality": baseline_daily_mortality,
        "epa_daily_df": epa_daily_df,
    }


def main():
    data = make_synthetic_data()

    print("=" * 70)
    print("ALGORITHM 1: Sensor Calibration Model Comparison")
    print("=" * 70)
    algo1_results = run_algorithm1(
        data["purpleair_df"], data["epa_df"], n_splits=5  # small n for a fast demo run
    )
    print(summarize_r2(algo1_results["r2_results"]))

    # exposure-response parameter (from external epidemiological literature)
    gamma_point, gamma_lo, gamma_hi = 0.0075, 0.0050, 0.0100
    baseline_pm25 = 12.0  # background/counterfactual PM2.5 level

    print("\n" + "=" * 70)
    print("ALGORITHM 2: Excess Mortality via Log-Linear Calibration")
    print("=" * 70)
    algo2_results = run_algorithm2(
        full_data_log_linear_fit=algo1_results["full_data_log_linear_fit"],
        synchronized_calibration_data=algo1_results["synchronized_calibration_data"],
        all_sensor_readings_df=data["all_sensor_readings_df"],
        tract_centroids=data["tract_centroids"],
        baseline_pm25=baseline_pm25,
        gamma_point=gamma_point, gamma_lo=gamma_lo, gamma_hi=gamma_hi,
        baseline_daily_mortality=data["baseline_daily_mortality"],
        population=data["population"],
        epa_daily_df=data["epa_daily_df"],
        m=5,  # small n for a fast demo run
    )
    print(algo2_results["point_estimate"])

    print("\n" + "=" * 70)
    print("ALGORITHM 3: Excess Mortality via MLP Calibration")
    print("=" * 70)
    algo3_results = run_algorithm3(
        full_training_data=algo1_results["synchronized_calibration_data"],
        all_sensor_readings_df=data["all_sensor_readings_df"],
        tract_centroids=data["tract_centroids"],
        baseline_pm25=baseline_pm25,
        gamma_point=gamma_point, gamma_lo=gamma_lo, gamma_hi=gamma_hi,
        baseline_daily_mortality=data["baseline_daily_mortality"],
        population=data["population"],
        m=3,  # small n for a fast demo run -- MLP retraining is expensive
    )
    print(algo3_results["ensemble_point_estimate"])

    print("\n" + "=" * 70)
    print("ALGORITHM 4: (pending -- building block only)")
    print("=" * 70)
    diff_df = compute_difference_from_uniform(
        algo2_results["point_estimate"], algo2_results["uniform_epa_only"]
    )
    print(diff_df)


if __name__ == "__main__":
    main()
