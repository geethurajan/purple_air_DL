"""
STAGE 1: Load EPA monitor, census tracts, and the full PurpleAir sensor
network; resample sensors to hourly; keep only sensors with at least
MIN_SENSOR_HOURS of data (set in pipeline_config.py).

Run: python stage1_load_and_filter_sensors.py

Writes to CHECKPOINTS_DIR:
    epa_data.csv               [timestamp, epa_pm25, latitude, longitude]
    tract_centroids.csv        [tract_id, lat, lon, x_km, y_km]
    population.csv             [tract_id, population]
    sensor_hour_counts.csv     [sensor_id, n_hours, kept]  -- inspect this to
                                 see exactly which sensors were dropped and why
    all_sensors_filtered.csv   [sensor_id, timestamp, date, lat, lon, x_km, y_km,
                                 pa_pm25, pa_temp, pa_humidity, pa_pressure]
                                 -- only sensors meeting the hour threshold
"""

from pipeline_config import (
    EPA_PATH, TRACTS_PATH, PURPLEAIR_SENSORS_DIR, SENSOR_METADATA_PATH,
    MIN_SENSOR_HOURS, ckpt,
)
from real_data_loaders import (
    load_epa_data, load_tract_data, load_all_purpleair_sensors,
    resample_to_hourly, filter_sensors_by_min_hours,
)


def main():
    print("Loading EPA monitor data...")
    epa_df = load_epa_data(EPA_PATH)
    epa_df.to_csv(ckpt("epa_data.csv"), index=False)
    print(f"  -> {len(epa_df)} hourly readings, "
          f"{epa_df['timestamp'].min()} to {epa_df['timestamp'].max()}")

    print("\nLoading census tract data...")
    tract_centroids, population = load_tract_data(TRACTS_PATH)
    tract_centroids.to_csv(ckpt("tract_centroids.csv"), index=False)
    population.to_csv(ckpt("population.csv"), index=False)
    print(f"  -> {len(tract_centroids)} tracts")

    print(f"\nLoading PurpleAir sensors from '{PURPLEAIR_SENSORS_DIR}' "
          f"(this can take a while for ~260 files)...")
    all_sensors = load_all_purpleair_sensors(
        PURPLEAIR_SENSORS_DIR, metadata_path=SENSOR_METADATA_PATH,
    )
    n_raw_sensors = all_sensors["sensor_id"].nunique()
    print(f"  -> {n_raw_sensors} sensors loaded, {len(all_sensors)} raw readings total")

    print("\nResampling every sensor to hourly...")
    all_sensors = resample_to_hourly(all_sensors)

    print(f"\nFiltering to sensors with >= {MIN_SENSOR_HOURS} hours of data...")
    filtered, hour_counts = filter_sensors_by_min_hours(all_sensors, min_hours=MIN_SENSOR_HOURS)

    hour_counts.to_csv(ckpt("sensor_hour_counts.csv"), index=False)
    filtered.to_csv(ckpt("all_sensors_filtered.csv"), index=False)

    print(f"\nSTAGE 1 COMPLETE. {filtered['sensor_id'].nunique()} of {n_raw_sensors} "
          f"sensors kept ({len(filtered)} hourly readings).")
    print(f"Checkpoints written to '{ckpt('')}'.")


if __name__ == "__main__":
    main()
