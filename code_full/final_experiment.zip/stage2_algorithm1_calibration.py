"""
STAGE 2: Identify the PurpleAir sensor closest to the EPA monitor, run
Algorithm 1 (log-linear vs. MLP calibration comparison), and save the
full-data log-linear coefficients for later stages.

Run: python stage2_algorithm1_calibration.py
(Reads checkpoints from Stage 1.)

Writes to CHECKPOINTS_DIR:
    closest_sensor_id.txt              -- which sensor was used for calibration
    log_linear_params.csv              -- full-data log-linear coefficients
                                           (carried forward to Stages 3 & 4)
    r2_comparison.csv                  -- paired R^2, log-linear vs. MLP,
                                           N_TIME_BLOCK_SPLITS time-block splits
    synchronized_calibration_data.csv  -- needed by Stage 4's bootstrap
"""

import pandas as pd

from pipeline_config import ckpt, N_TIME_BLOCK_SPLITS
from real_data_loaders import get_epa_site_location, find_closest_sensor
from calibration_models import save_log_linear_params
from algorithm1_model_comparison import run_algorithm1, summarize_r2


def main():
    print("Loading Stage 1 checkpoints...")
    epa_df = pd.read_csv(ckpt("epa_data.csv"), parse_dates=["timestamp"])
    all_sensors = pd.read_csv(ckpt("all_sensors_filtered.csv"), parse_dates=["timestamp"],
                               dtype={"sensor_id": str})

    epa_lat, epa_lon = get_epa_site_location(epa_df)
    closest_sensor_id = find_closest_sensor(all_sensors, epa_lat, epa_lon)
    print(f"Closest PurpleAir sensor to EPA monitor ({epa_lat}, {epa_lon}): {closest_sensor_id}")

    with open(ckpt("closest_sensor_id.txt"), "w") as f:
        f.write(str(closest_sensor_id))

    purpleair_calibration_df = all_sensors[all_sensors["sensor_id"] == closest_sensor_id].copy()
    print(f"Calibration sensor has {len(purpleair_calibration_df)} hourly readings.")

    print(f"\nRunning Algorithm 1 ({N_TIME_BLOCK_SPLITS} time-block splits; this may take a while)...")
    algo1_results = run_algorithm1(purpleair_calibration_df, epa_df, n_splits=N_TIME_BLOCK_SPLITS)

    print("\nR^2 comparison summary:")
    print(summarize_r2(algo1_results["r2_results"]))

    save_log_linear_params(algo1_results["full_data_log_linear_fit"], ckpt("log_linear_params.csv"))
    algo1_results["r2_results"].to_csv(ckpt("r2_comparison.csv"), index=False)
    algo1_results["synchronized_calibration_data"].to_csv(ckpt("synchronized_calibration_data.csv"), index=False)

    print(f"\nSTAGE 2 COMPLETE. Checkpoints written to '{ckpt('')}'.")


if __name__ == "__main__":
    main()
