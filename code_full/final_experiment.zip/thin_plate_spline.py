"""
Classical penalized thin plate spline (Duchon/Wahba formulation), matching
the paper's Eq. 6:

    argmin_f { sum_i (Z(s_i) - f(s_i))^2
               + lambda * integral[ (d2f/dx2)^2 + 2*(d2f/dxdy)^2 + (d2f/dy2)^2 ] dx dy }

This is a SMOOTHING spline (does not pass exactly through every data point),
not an exact interpolator. The paper fits this with R's `fields::Tps`,
using a FIXED lambda = 1e-3 for both the pre-fire and during-fire datasets.

We solve it directly via the standard radial basis function representation
for 2D thin plate splines:

    f(s) = sum_i w_i * phi(||s - s_i||) + a0 + a1*x + a2*y,   phi(r) = r^2 log(r)

by solving the linear system

    [ K + lambda*I   P ] [w]   [z]
    [ P^T            0 ] [a] = [0]

where K_ij = phi(||s_i - s_j||) and P is the linear polynomial basis [1, x_i, y_i].

IMPORTANT: fit and predict in a locally-planar coordinate system (e.g. km
from a reference point), NOT raw lat/lon degrees -- lat/lon degrees are not
an isotropic distance metric, and R's `fields::Tps` operates on whatever
coordinate matrix you give it, so if you feed it lat/lon directly you get a
different (distorted) notion of distance than if you use projected km. Use
`project_to_km()` from real_data_loaders.py to build consistent x_km/y_km
columns for sensors, EPA site, and tract centroids before calling this.
"""

import numpy as np


def _tps_kernel(r):
    """phi(r) = r^2 * log(r), with phi(0) := 0 (the well-known removable singularity)."""
    with np.errstate(divide="ignore", invalid="ignore"):
        out = np.where(r > 0, r ** 2 * np.log(r), 0.0)
    return out


def _pairwise_dist(a, b):
    """Euclidean distance matrix between rows of a (n,2) and rows of b (m,2)."""
    diff = a[:, None, :] - b[None, :, :]
    return np.sqrt(np.sum(diff ** 2, axis=-1))


class ThinPlateSpline:
    """
    Fits the penalized thin plate spline in Eq. 6 with a fixed lambda.

    Parameters
    ----------
    lambda_ : smoothing penalty (paper uses 1e-3, fixed for both pre-fire
        and during-fire periods "as this choice was found to be a good
        compromise between flexibility of the model and smooth spatial
        patterns").
    """

    def __init__(self, lambda_: float = 1e-3):
        self.lambda_ = lambda_
        self._train_coords = None
        self._w = None
        self._a = None

    def fit(self, coords: np.ndarray, values: np.ndarray):
        """
        coords : (n, 2) array of [x, y] in a planar (e.g. km) coordinate system.
        values : (n,) array of observed values at those coordinates.
        """
        coords = np.asarray(coords, dtype=float)
        values = np.asarray(values, dtype=float)
        n = coords.shape[0]
        if n < 3:
            raise ValueError("Thin plate spline needs at least 3 non-collinear points.")

        K = _tps_kernel(_pairwise_dist(coords, coords))
        P = np.column_stack([np.ones(n), coords[:, 0], coords[:, 1]])  # [1, x, y]

        # Assemble the (n+3) x (n+3) system:
        #   [K + lambda*I   P] [w]   [z]
        #   [P^T            0] [a] = [0]
        top = np.hstack([K + self.lambda_ * np.eye(n), P])
        bottom = np.hstack([P.T, np.zeros((3, 3))])
        A = np.vstack([top, bottom])
        rhs = np.concatenate([values, np.zeros(3)])

        try:
            sol = np.linalg.solve(A, rhs)
        except np.linalg.LinAlgError:
            # fall back to least-squares if the system is (near-)singular,
            # e.g. very few / collinear sensor locations on a given day
            sol, *_ = np.linalg.lstsq(A, rhs, rcond=None)

        self._w = sol[:n]
        self._a = sol[n:]
        self._train_coords = coords
        return self

    def predict(self, query_coords: np.ndarray) -> np.ndarray:
        """query_coords : (m, 2) array of [x, y] in the same planar coordinate system as fit()."""
        if self._w is None:
            raise RuntimeError("Call fit() before predict().")
        query_coords = np.asarray(query_coords, dtype=float)

        K_query = _tps_kernel(_pairwise_dist(query_coords, self._train_coords))
        P_query = np.column_stack([np.ones(len(query_coords)), query_coords[:, 0], query_coords[:, 1]])

        return K_query @ self._w + P_query @ self._a


def fit_predict_tps(train_coords, train_values, query_coords, lambda_: float = 1e-3):
    """Convenience one-shot fit + predict."""
    tps = ThinPlateSpline(lambda_=lambda_)
    tps.fit(train_coords, train_values)
    return tps.predict(query_coords)
